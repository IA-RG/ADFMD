package com.example.examen2;

import android.os.Bundle;
import android.app.Activity;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.*;

public class MainActivity extends Activity {
    EditText jetV, jetN, jetA;;
    Button jbnA, jbnL, jbnB;
    TextView jtvL;
    SQLiteDatabase sqld;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        jetV = (EditText) findViewById(R.id.xetV);
        jetN = (EditText) findViewById(R.id.xetN);
        jetA = (EditText) findViewById(R.id.xetA);
        jbnA = (Button) findViewById(R.id.xbnA);
        jbnL = (Button) findViewById(R.id.xbnL);
        jbnB = (Button) findViewById(R.id.xbnB);
        jtvL = (TextView) findViewById(R.id.xtvL);
        DbmsSQLiteHelper dsqlh = new DbmsSQLiteHelper(this, "DBPaises", null, 1);
        sqld = dsqlh.getWritableDatabase();

        jbnA.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                String latitud = jetV.getText().toString();
                String longitud = jetA.getText().toString();
                String nombre = jetN.getText().toString();
                ContentValues cv = new ContentValues();
                cv.put("nombre", nombre);
                cv.put("Latitud", latitud);
                cv.put("Longitud", longitud);
                sqld.insert("Paises", null, cv);
                jetV.setText("");
                jetN.setText("");
                jetA.setText("");
            }
        });

        jbnB.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                String latitud = jetV.getText().toString();
                String longitud = jetA.getText().toString();
                String nombre = jetN.getText().toString();
                sqld.delete("Paises","nombre = ? ", new String[] {nombre});
                jetV.setText("");
                jetN.setText("");
                jetA.setText("");
            }
        });

        jbnL.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                String nombre, latitud, longitud;
                Cursor c = sqld.rawQuery("SELECT nombre, latitud, longitud FROM Paises", null);
                jtvL.setText("Nombre \t Latitud \t Longitud \n ");
                if (c.moveToFirst()) {
                    do {
                        nombre = c.getString(0);
                        latitud = c.getString(1);
                        longitud = c.getString(2);
                        jtvL.append(", " + nombre + "\t"+ " , "  + latitud + " , " + longitud + "\n");
                    } while(c.moveToNext());
                }
            }
        });
    }
}